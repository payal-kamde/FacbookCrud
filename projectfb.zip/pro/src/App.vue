<template>
  <div id="app">
    <head>
        <title>Facebook</title>
        <link href="style.css" type="text/css" rel="stylesheet"/>
        <link rel="icon" type="image/x-icon" href="https://icons.iconarchive.com/icons/yootheme/social-bookmark/512/social-facebook-box-blue-icon.png">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <header>
            <div class="header">
                <li class="sitename"><a href="http://Facebook.com">Facebook</a></li>
                 <form name="f1" onsubmit="validatefunction()" action="post">
                    <li>Email or Phone<br><input type="text" name="email" class="e"></li>
                    <li>Password<br><input type="password" name="password" class="p"><br><a href="">Forgotten account?</a></li>
                    <li><input type="submit" name="login" value="Log In" class="b"></li>
                </form> 
            </div>
        </header>
        <div class="wrapper">
            <div class="div1">
                <p><B>Connect with friends and the <br>world around you on Facebook.</B></p>
                <br><br>
                <p><i class="fa fa-newspaper-o" aria-hidden="true"></i> <B>See photos and updates</B> from friends in New Feed. </p><br><br>
                <p><i class="fa fa-television" aria-hidden="true"></i> <B>Share what's new</B> in your life on your Timeline. </p><br><br>
                <p><i class="fa fa-share-alt-square" aria-hidden="true"></i> <B>Find more</B> of what you're looking for with Facebook Search. </p>
            </div>
           <div class="div2">
                <h1>Sign Up</h1>
                <p>It's free and always will be.</p>
                <form id="facebook">
                    <li>
                      <input type="text" placeholder="Username" name="Username" id="username">
                      <div class="success" id="user-error-block"></div>
                    </li>
                    <li>
                      <input type="text" placeholder="Email" name="Email" id="email">
                      <div id="email-error-block"></div>
                    </li>
                    <li>
                      <input type="password" placeholder="Password" name="Password" id="password">
                      <div id="password-error-block"></div>
                    </li>
                    <li>
                      <input type="password" placeholder="Confirm password" name="Password" id="confirm-password">
                      <div id="confirm-password-error-block"></div>
                    </li>
                    <li>
                      <input type="radio">Female <input type="radio">Male
                    </li>
                    <li class="terms">By clicking Sign Up,, you agree to our  <a href="">Teams. Data Police</a> and  <br><a href="">Cookies Policy </a>you may receive SMS Notification from us and <br>can opt out any time.</li>
                    <li>
                      <input type="submit" value="Sign Up" class="sub" id="signup">
                      <div id="submit-error-block"></div>
                    </li>
                </form>
            </div>
        </div>
        <footer>
            <p><a href="facebook.com">facebook.com</a></p>
        </footer>
    </body>
  </div>
</template>

<script>
export default {
  
  data()
  {
    

  }

  
}
</script>>

<style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  body
  {
      text-align:center;
      width:100%;
      margin:0 auto;
      padding:0px;
      font-family:"lucida grande",tahoma,verdana,arial,sans-serif;
      background: linear-gradient(white, #D3D8E8);
  }
  header
  {
      width:100%;
      min-width:980px;
      background-color:#4c66a4;
  }
  .header
  {
      width:980px;
      margin:0px auto;
      padding:0px;
      height:85px;
      }
  .header li
  {
      list-style-type:none;
      float:left;
      text-align:left;
      color:white;
  }
  .header .sitename
  {
      margin-top:25px;
  }
  .header .sitename a
  {
      color:white;
      text-decoration:none;
      font-size:30px;
      font-weight:900;   
  }
  .header form
  {
      margin-top:15px;
      float:right;
  }
  .header form li
  {
      font-size:13px;
      margin-left:15px;
  }
  .header form li a
  {
      color:#A9BCF5;
      text-decoration:none;
  }
  .e
  {
      margin-top:3px;
      margin-bottom:3px;
      width:150px;
      border:1px solid #08298A;
      height:25px;
      padding-left:3px;
  }
  .p
  {
      margin-top:3px;
      margin-bottom:3px;
      width:150px;
      border:1px solid #08298A;
      height:25px;
      padding-left:30px;
  }
  .b
  {
      height:25px;
      margin-top:20px;
      background-color:#084B8A;
      color:white;
      border:1px solid #08298A;
  }
  .wrapper
  {
      margin:0 auto;
      padding:0px;
      text-align:center;
      width:990px;
  }
  .wrapper div
  {
      float:left;
      font-family: helvetica, arial, sans-serif;
  }
  .wrapper .div1
  {
      margin-top:30px;
      width:590px;
      text-align:left;
  }
  .wrapper .div1 p
  {
      font-size:20px;
      font-family:arial;
      font-weight:bold;
      margin:0px;
      color:#000000;
  }
  .wrapper .div2
  {
      margin-top:10px;
      width:390px;
      text-align:left;
  }
  .wrapper .div2 h1
  {
      margin:0px;
      font-size:37px;
      color:#2E2E2E;
  }
  .wrapper .div2 p
  {
      font-size:18px;
      color:#2E2E2E;
  }
  .wrapper .div2 li
  {
      list-style-type:none;
      margin-top:10px;
  }
  .error{
      color:red;
      font-size: small;
  }
  #username
  {
      width:100%;
      height:40px;
      border-radius:5px;
      padding-left:10px;
      font-size:18px;
      border:1px solid #BDBDBD;
  }
  #email
  {
      width:100%;
      height:40px;
      border-radius:5px;
      padding-left:10px;
      font-size:18px;
      border:1px solid #BDBDBD;
  }
  #password
  {
      width:100%;
      height:40px;
      border-radius:5px;
      padding-left:10px;
      font-size:18px;
      border:1px solid #BDBDBD;
  }
  #confirm-password
  {
      width:100%;
      height:40px;
      border-radius:5px;
      padding-left:10px;
      font-size:18px;
      border:1px solid #BDBDBD;
  }
  .wrapper .div2 li select
  {
      padding:4px;
      float:left;
  }
  .wrapper .div2 li a
  {
      margin-left:10px;
      width:150px;
      color:#045FB4;
      text-decoration:none;
      font-size:11px;
      display: inline-block;
      vertical-align: middle;
      line-height:15px;
  }
  .wrapper .div2 li a:hover
  {
      text-decoration:underline;
  }
  .wrapper .div2 li
  {
      color:#2E2E2E;
      font-size:18px;
  }
  .wrapper .div2 li.terms 
  {
      color:#424242;
      font-size:11px;
  }.wrapper .div2 li.terms a
  {
      display:inline;
      margin:0px;
      font-size:11px;
  }
  .sub
  {
      width:205px;
      height:45px;
      text-align:center;
      font-size:19px;
      margin-top: 10px;
      margin-bottom: 10px;
      font-family: 'Freight Sans Bold', helvetica, arial, sans-serif !important;
      font-weight: bold !important;
      background: linear-gradient(#67ae55, #578843);
      background-color: #69a74e;
      box-shadow: inset 0 1px 1px #a4e388;
      border-color: #3b6e22 #3b6e22 #2c5115;
      border: 1px solid;
      border-radius: 5px;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      position: relative;
      text-shadow: 0 1px 2px rgba(0,0,0,.5);
  }
  footer
  {
      margin-top:47%;
      width:100%;
      min-width:980px;
      background-color:#4c66a4;
      text-align: center;
      height: 50px;
      padding-top: 15px;
      padding-bottom: 15px;
      
  }
</style>
